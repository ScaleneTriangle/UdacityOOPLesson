from setuptools import setup

setup(name='distributions_ajkr',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_ajkr'],
      zip_safe=False)
